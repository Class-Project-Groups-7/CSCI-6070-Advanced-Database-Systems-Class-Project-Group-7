public class MovieDb {
	public static void main(String[] args) {
		MovieController movieController=new MovieController();
		//movieController.getTopRatingMovies();
		//movieController.getTopTenDirecterNames();
		//movieController.getTopTenTvSeries();
		//movieController.getCountOfParticularRating();
		//movieController.getInfoTvEpisodesNotNull();
		//movieController.getInfoMoivieRunTimeMinutes();
		//movieController.getInfoMoivieTitleDirectedby();
		
	}

}
